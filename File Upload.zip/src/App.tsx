import { useState } from 'react';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ToastContainer from './components/ToastContainer';
import { useToast } from './hooks/useToast';

export default function App() {
  const [user, setUser] = useState<string | null>(null);
  const { toasts, addToast, removeToast } = useToast();

  return (
    <div className="size-full">
      {user ? (
        <DashboardPage
          username={user}
          onLogout={() => setUser(null)}
          addToast={addToast}
        />
      ) : (
        <LoginPage
          onLogin={setUser}
          addToast={addToast}
        />
      )}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
}
