import { Trash2, RefreshCw, CheckCircle, XCircle, Clock, Loader2, Eye, Download } from 'lucide-react';
import type { UploadFile } from '../types/upload';
import FileIcon from './FileIcon';

function fmt(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(0)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

function dl(file: File, name: string) {
  const url = URL.createObjectURL(file);
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

const SC = {
  pending:   { icon: <Clock size={11} />,   label:'Waiting',   color:'var(--color-text-dim)',  bg:'var(--color-surface-2)', border:'var(--color-border)' },
  uploading: { icon: <Loader2 size={11} className="animate-spin" />, label:'Uploading', color:'var(--color-orange)', bg:'var(--color-orange-light)', border:'var(--color-orange-mid)' },
  completed: { icon: <CheckCircle size={11} />, label:'Done',   color:'var(--color-success)', bg:'var(--color-success-bg)', border:'#bbf7d0' },
  failed:    { icon: <XCircle size={11} />,  label:'Failed',   color:'var(--color-error)',   bg:'var(--color-error-bg)',   border:'#fecaca' },
  cancelled: { icon: <Clock size={11} />,   label:'Cancelled', color:'var(--color-text-dim)', bg:'var(--color-surface-2)', border:'var(--color-border)' },
};

function ActionBtn({ onClick, title, children, hoverBg, hoverColor }: {
  onClick: () => void; title: string; children: React.ReactNode; hoverBg: string; hoverColor: string;
}) {
  return (
    <button
      onClick={onClick} title={title}
      style={{ width:'28px', height:'28px', borderRadius:'7px', border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--color-text-dim)', transition:'all 0.12s' }}
      onMouseEnter={e => { e.currentTarget.style.background=hoverBg; e.currentTarget.style.color=hoverColor; }}
      onMouseLeave={e => { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--color-text-dim)'; }}
    >
      {children}
    </button>
  );
}

function Checkbox({ checked, indeterminate, onChange }: { checked: boolean; indeterminate?: boolean; onChange: (v: boolean) => void }) {
  return (
    <label style={{ display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer' }}>
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} className="sr-only" />
      <div style={{
        width:'16px', height:'16px', borderRadius:'5px', display:'flex', alignItems:'center', justifyContent:'center', transition:'all 0.12s',
        background: checked ? 'var(--color-navy)' : indeterminate ? 'var(--color-navy)' : '#fff',
        border: `1.5px solid ${checked || indeterminate ? 'var(--color-navy)' : 'var(--color-border-light)'}`,
      }}>
        {checked && <svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1.5 4.5l2.5 2.5 4-4.5" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
        {!checked && indeterminate && <div style={{ width:'8px', height:'2px', borderRadius:'1px', background:'#fff' }} />}
      </div>
    </label>
  );
}

interface TableProps {
  files: UploadFile[];
  onToggle: (id: string) => void; onToggleAll: (v: boolean) => void;
  onRemove: (id: string) => void; onRetry: (id: string) => void; onView: (id: string) => void;
}

export default function FileTable({ files, onToggle, onToggleAll, onRemove, onRetry, onView }: TableProps) {
  if (files.length === 0) return null;

  const allSelected  = files.every(f => f.selected);
  const someSelected = files.some(f => f.selected);
  const selCount     = files.filter(f => f.selected).length;

  return (
    <div style={{ borderRadius:'14px', overflow:'hidden', background:'var(--color-surface)', border:'1px solid var(--color-border)', boxShadow:'0 1px 4px rgba(13,27,42,0.06)' }}>

      {/* Desktop/tablet head */}
      <div className="file-table-head">
        <Checkbox checked={allSelected} indeterminate={!allSelected && someSelected} onChange={onToggleAll} />
        <div />
        <span style={{ fontSize:'0.72rem', fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.08em' }}>File</span>
        <span className="col-size" style={{ fontSize:'0.72rem', fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.08em', textAlign:'right' }}>Size</span>
        <span style={{ fontSize:'0.72rem', fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.08em', textAlign:'center' }}>Status</span>
        <span style={{ fontSize:'0.72rem', fontWeight:600, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:'0.08em', textAlign:'right' }}>
          {selCount} / {files.length} selected
        </span>
      </div>

      {/* Desktop/tablet rows */}
      {files.map(f => {
        const s = SC[f.status];
        return (
          <div key={f.id}>
            {/* Desktop row */}
            <div
              className="file-table-row"
              onMouseEnter={e => (e.currentTarget.style.background='#f8fafc')}
              onMouseLeave={e => (e.currentTarget.style.background='transparent')}
            >
              <Checkbox checked={f.selected} onChange={() => onToggle(f.id)} />
              <FileIcon ext={f.ext} size={26} />
              <div style={{ minWidth:0 }}>
                <p style={{ fontSize:'0.8125rem', fontWeight:500, color:'var(--color-text)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }} title={f.name}>{f.name}</p>
                <div style={{ display:'flex', alignItems:'center', gap:'8px', marginTop:'5px' }}>
                  <div style={{ height:'3px', borderRadius:'2px', background:'var(--color-border)', overflow:'hidden', flex:1, maxWidth:'100px' }}>
                    <div style={{ height:'100%', borderRadius:'2px', width:`${f.progress}%`, transition:'width 0.3s', background: f.status==='completed' ? 'var(--color-success)' : f.status==='failed' ? 'var(--color-error)' : 'linear-gradient(90deg,var(--color-orange-hover),var(--color-orange))' }} />
                  </div>
                  <span style={{ fontSize:'0.7rem', fontFamily:'var(--font-mono)', color:'var(--color-text-dim)', minWidth:'28px' }}>{f.progress}%</span>
                </div>
              </div>
              <span className="col-size" style={{ fontSize:'0.75rem', fontFamily:'var(--font-mono)', color:'var(--color-text-dim)', textAlign:'right' }}>{fmt(f.size)}</span>
              <div className="col-status" style={{ justifyContent:'center' }}>
                <div style={{ display:'flex', alignItems:'center', gap:'4px', fontSize:'0.72rem', fontWeight:600, padding:'3px 8px', borderRadius:'6px', color:s.color, background:s.bg, border:`1px solid ${s.border}`, whiteSpace:'nowrap' }}>
                  {s.icon} <span>{s.label}</span>
                </div>
              </div>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'flex-end', gap:'2px' }}>
                <ActionBtn onClick={() => onView(f.id)} title="Preview" hoverBg='var(--color-blue-light)' hoverColor='var(--color-blue)'><Eye size={13} /></ActionBtn>
                <ActionBtn onClick={() => dl(f.file, f.name)} title="Download" hoverBg='var(--color-success-bg)' hoverColor='var(--color-success)'><Download size={13} /></ActionBtn>
                {f.status === 'failed' && <ActionBtn onClick={() => onRetry(f.id)} title="Retry" hoverBg='var(--color-orange-light)' hoverColor='var(--color-orange)'><RefreshCw size={12} /></ActionBtn>}
                <ActionBtn onClick={() => onRemove(f.id)} title="Remove" hoverBg='var(--color-error-bg)' hoverColor='var(--color-error)'><Trash2 size={13} /></ActionBtn>
              </div>
            </div>

            {/* Mobile card */}
            <div className="file-card" style={{ display:'none', padding:'12px 14px', borderBottom:'1px solid var(--color-border)', flexDirection:'column', gap:'10px' }}>
              <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
                <Checkbox checked={f.selected} onChange={() => onToggle(f.id)} />
                <FileIcon ext={f.ext} size={28} />
                <div style={{ flex:1, minWidth:0 }}>
                  <p style={{ fontSize:'0.84rem', fontWeight:600, color:'var(--color-text)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }} title={f.name}>{f.name}</p>
                  <span style={{ fontSize:'0.7rem', fontFamily:'var(--font-mono)', color:'var(--color-text-dim)' }}>{fmt(f.size)}</span>
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:'4px', fontSize:'0.68rem', fontWeight:600, padding:'3px 8px', borderRadius:'6px', color:s.color, background:s.bg, border:`1px solid ${s.border}`, flexShrink:0 }}>
                  {s.icon}
                </div>
              </div>
              <div style={{ height:'3px', borderRadius:'2px', background:'var(--color-border)', overflow:'hidden' }}>
                <div style={{ height:'100%', borderRadius:'2px', width:`${f.progress}%`, transition:'width 0.3s', background: f.status==='completed' ? 'var(--color-success)' : f.status==='failed' ? 'var(--color-error)' : 'linear-gradient(90deg,var(--color-orange-hover),var(--color-orange))' }} />
              </div>
              <div style={{ display:'flex', justifyContent:'flex-end', gap:'4px' }}>
                <ActionBtn onClick={() => onView(f.id)} title="Preview" hoverBg='var(--color-blue-light)' hoverColor='var(--color-blue)'><Eye size={13} /></ActionBtn>
                <ActionBtn onClick={() => dl(f.file, f.name)} title="Download" hoverBg='var(--color-success-bg)' hoverColor='var(--color-success)'><Download size={13} /></ActionBtn>
                {f.status === 'failed' && <ActionBtn onClick={() => onRetry(f.id)} title="Retry" hoverBg='var(--color-orange-light)' hoverColor='var(--color-orange)'><RefreshCw size={12} /></ActionBtn>}
                <ActionBtn onClick={() => onRemove(f.id)} title="Remove" hoverBg='var(--color-error-bg)' hoverColor='var(--color-error)'><Trash2 size={13} /></ActionBtn>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
