interface Props { ext: string; size?: number; }

const colorMap: Record<string, string> = {
  pdf: '#ef4444', doc: '#3b82f6', docx: '#3b82f6',
  xls: '#22c55e', xlsx: '#22c55e', csv: '#22c55e',
  ppt: '#f97316', pptx: '#f97316',
  txt: '#94a3b8', jpg: '#a855f7', jpeg: '#a855f7',
  png: '#a855f7', gif: '#ec4899',
  zip: '#f59e0b', rar: '#f59e0b',
};

export default function FileIcon({ ext, size = 32 }: Props) {
  const color = colorMap[ext] ?? '#8892a4';
  const label = ext.toUpperCase().slice(0, 4);
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <rect x="3" y="1" width="20" height="26" rx="3" fill={color} fillOpacity="0.12" stroke={color} strokeOpacity="0.5" strokeWidth="1"/>
      <path d="M18 1v6h5" stroke={color} strokeOpacity="0.6" strokeWidth="1" strokeLinejoin="round"/>
      <text x="16" y="22" textAnchor="middle" fontSize="6.5" fontFamily="JetBrains Mono, monospace" fontWeight="600" fill={color}>
        {label}
      </text>
    </svg>
  );
}
