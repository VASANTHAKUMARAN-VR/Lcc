import { Upload, XCircle, RefreshCw, Trash2, CheckSquare } from 'lucide-react';
import type { UploadFile } from '../types/upload';

interface BtnProps {
  onClick: () => void; disabled?: boolean;
  icon: React.ReactNode; label: string;
  variant?: 'primary' | 'ghost' | 'danger';
}

function Btn({ onClick, disabled, icon, label, variant = 'ghost' }: BtnProps) {
  const base: React.CSSProperties = {
    display:'flex', alignItems:'center', gap:'6px',
    padding:'7px 14px', borderRadius:'9px', fontSize:'0.8125rem', fontWeight:600,
    cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.4 : 1,
    transition:'all 0.15s', border:'none', fontFamily:'var(--font-sans)',
  };
  const styles: Record<string, React.CSSProperties> = {
    primary: { ...base, background:'var(--color-navy)', color:'#fff', boxShadow:'0 2px 10px rgba(13,27,42,0.18)' },
    ghost:   { ...base, background:'var(--color-surface)', color:'var(--color-text-muted)', border:'1px solid var(--color-border)' },
    danger:  { ...base, background:'var(--color-error-bg)', color:'var(--color-error)', border:'1px solid #fecaca' },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={styles[variant]}
      onMouseEnter={e => { if(!disabled) e.currentTarget.style.opacity='0.85'; }}
      onMouseLeave={e => { e.currentTarget.style.opacity='1'; }}
    >
      {icon}
      <span className="ctrl-label">{label}</span>
    </button>
  );
}

interface Props {
  files: UploadFile[]; uploading: boolean;
  onUploadAll: () => void; onCancelAll: () => void;
  onRetryFailed: () => void; onRemoveSelected: () => void; onClearAll: () => void;
}

export default function UploadControls({ files, uploading, onUploadAll, onCancelAll, onRetryFailed, onRemoveSelected, onClearAll }: Props) {
  const selected      = files.filter(f => f.selected);
  const hasFailed     = files.some(f => f.status === 'failed');
  const hasUploadable = selected.some(f => f.status === 'pending' || f.status === 'failed');

  return (
    <div className="upload-controls">
      <Btn onClick={onUploadAll}      disabled={!hasUploadable || uploading} icon={<Upload size={13} />}      label="Upload All"      variant="primary" />
      {uploading && <Btn onClick={onCancelAll} icon={<XCircle size={13} />}   label="Cancel"         variant="ghost" />}
      <Btn onClick={onRetryFailed}    disabled={!hasFailed || uploading}     icon={<RefreshCw size={13} />}   label="Retry Failed"    variant="ghost" />
      <Btn onClick={onRemoveSelected} disabled={selected.length === 0}       icon={<CheckSquare size={13} />} label="Remove Selected" variant="ghost" />
      <Btn onClick={onClearAll}       disabled={files.length === 0}          icon={<Trash2 size={13} />}      label="Clear All"       variant="danger" />
    </div>
  );
}
