import type { UploadFile } from '../types/upload';

function fmt(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

export default function OverallProgress({ files, uploading }: { files: UploadFile[]; uploading: boolean }) {
  if (files.length === 0) return null;

  const completed = files.filter(f => f.status === 'completed').length;
  const failed    = files.filter(f => f.status === 'failed').length;
  const total     = files.length;
  const totalSize = files.reduce((s, f) => s + f.size, 0);
  const pct       = total === 0 ? 0 : Math.round(files.reduce((sum, f) => sum + f.progress, 0) / total);
  const isAllDone = !uploading && (completed + failed === total) && total > 0;

  const barColor = pct === 100 ? 'var(--color-success)' : 'linear-gradient(90deg, var(--color-orange-hover), var(--color-orange))';

  return (
    <div style={{ borderRadius:'14px', padding:'1.25rem 1.5rem', background:'var(--color-surface)', border:'1px solid var(--color-border)', boxShadow:'0 1px 4px rgba(13,27,42,0.06)' }}>
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:'0.875rem' }}>
        <div>
          <p style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'0.9rem', color:'var(--color-navy)', marginBottom:'2px' }}>
            {uploading ? 'Uploading Files…' : isAllDone ? 'Upload Complete' : 'Upload Queue'}
          </p>
          <p style={{ fontSize:'0.775rem', color:'var(--color-text-muted)' }}>
            {completed} of {total} completed
            {failed > 0 && <span style={{ color:'var(--color-error)' }}> · {failed} failed</span>}
            {' · '}{fmt(totalSize)}
          </p>
        </div>
        <span style={{ fontFamily:'var(--font-mono)', fontWeight:700, fontSize:'1.25rem', color: pct === 100 ? 'var(--color-success)' : 'var(--color-orange)' }}>
          {pct}%
        </span>
      </div>

      {/* Bar */}
      <div style={{ height:'6px', borderRadius:'3px', background:'var(--color-border)', overflow:'hidden' }}>
        <div style={{ height:'100%', borderRadius:'3px', width:`${pct}%`, background:barColor, transition:'width 0.3s ease' }} />
      </div>

      {/* Summary stats */}
      {isAllDone && (
        <div className="animate-fade-in progress-stats" style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'10px', marginTop:'1rem' }}>
          {[
            { label:'Total',    value:total,     color:'var(--color-navy)',   bg:'var(--color-surface-2)' },
            { label:'Uploaded', value:completed, color:'var(--color-success)', bg:'var(--color-success-bg)' },
            { label:'Failed',   value:failed,    color: failed > 0 ? 'var(--color-error)' : 'var(--color-text-dim)', bg: failed > 0 ? 'var(--color-error-bg)' : 'var(--color-surface-2)' },
          ].map(s => (
            <div key={s.label} className="progress-stat" style={{ textAlign:'center', borderRadius:'10px', padding:'10px', background:s.bg }}>
              <p className="progress-stat-val" style={{ fontFamily:'var(--font-mono)', fontWeight:700, fontSize:'1.25rem', color:s.color }}>{s.value}</p>
              <p style={{ fontSize:'0.72rem', color:'var(--color-text-dim)', marginTop:'2px' }}>{s.label}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
