import { useEffect, useRef } from 'react';
import { X, Download, FileText, File } from 'lucide-react';
import type { UploadFile } from '../types/upload';

interface Props { file: UploadFile; onClose: () => void; }

const IMAGE_EXTS = new Set(['jpg','jpeg','png','gif','webp','svg']);
const PDF_EXTS   = new Set(['pdf']);
const TEXT_EXTS  = new Set(['txt','csv']);

function dl(file: File, name: string) {
  const url = URL.createObjectURL(file);
  const a = document.createElement('a'); a.href=url; a.download=name; a.click();
  URL.revokeObjectURL(url);
}

export default function FileViewer({ file, onClose }: Props) {
  const urlRef = useRef<string|null>(null);

  useEffect(() => {
    urlRef.current = URL.createObjectURL(file.file);
    return () => { if (urlRef.current) URL.revokeObjectURL(urlRef.current); };
  }, [file.file]);

  const isImage = IMAGE_EXTS.has(file.ext);
  const isPDF   = PDF_EXTS.has(file.ext);
  const isText  = TEXT_EXTS.has(file.ext);

  return (
    <div className="modal-backdrop" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div
        className="animate-scale-in modal-inner"
        style={{
          display:'flex', flexDirection:'column', borderRadius:'16px', overflow:'hidden',
          background:'var(--color-surface)', border:'1px solid var(--color-border)',
          boxShadow:'0 24px 80px rgba(13,27,42,0.3)',
          width:'100%', maxWidth: isPDF ? '900px' : isImage ? '840px' : '500px', maxHeight:'90vh',
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 16px', background:'var(--color-navy)', borderBottom:'1px solid rgba(255,255,255,0.07)', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:'10px', minWidth:0 }}>
            <div style={{ width:'30px', height:'30px', borderRadius:'8px', background:'rgba(249,115,22,0.2)', border:'1px solid rgba(249,115,22,0.3)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--color-orange)', flexShrink:0 }}>
              <FileText size={14} />
            </div>
            <div style={{ minWidth:0 }}>
              <p style={{ fontSize:'0.875rem', fontWeight:600, color:'#fff', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{file.name}</p>
              <p style={{ fontSize:'0.72rem', color:'rgba(255,255,255,0.4)', fontFamily:'var(--font-mono)' }}>
                {file.ext.toUpperCase()} · {(file.size/1024).toFixed(0)} KB
              </p>
            </div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:'8px', flexShrink:0 }}>
            <button
              onClick={() => dl(file.file, file.name)}
              style={{ display:'flex', alignItems:'center', gap:'6px', padding:'6px 12px', borderRadius:'8px', fontSize:'0.8rem', fontWeight:700, cursor:'pointer', border:'none', background:'var(--color-orange)', color:'#fff', fontFamily:'var(--font-display)', boxShadow:'0 2px 8px rgba(249,115,22,0.3)', transition:'background 0.15s' }}
              onMouseEnter={e => (e.currentTarget.style.background='var(--color-orange-hover)')}
              onMouseLeave={e => (e.currentTarget.style.background='var(--color-orange)')}
            >
              <Download size={13} /> Download
            </button>
            <button
              onClick={onClose}
              style={{ width:'30px', height:'30px', borderRadius:'8px', border:'none', background:'rgba(255,255,255,0.08)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'rgba(255,255,255,0.5)', transition:'all 0.12s' }}
              onMouseEnter={e => { e.currentTarget.style.background='rgba(255,255,255,0.15)'; e.currentTarget.style.color='#fff'; }}
              onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,0.08)'; e.currentTarget.style.color='rgba(255,255,255,0.5)'; }}
            >
              <X size={15} />
            </button>
          </div>
        </div>

        {/* Body */}
        <div style={{ flex:1, overflow:'auto', display:'flex', alignItems:'center', justifyContent:'center', background:'#f8fafc', minHeight:'280px' }}>
          {isImage && urlRef.current && (
            <img src={urlRef.current} alt={file.name} style={{ maxWidth:'100%', maxHeight:'75vh', objectFit:'contain', padding:'1.5rem' }} />
          )}
          {isPDF && urlRef.current && (
            <iframe src={urlRef.current} title={file.name} style={{ width:'100%', height:'75vh', border:'none' }} />
          )}
          {isText && urlRef.current && <TextPreview url={urlRef.current} />}
          {!isImage && !isPDF && !isText && (
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:'16px', padding:'3rem', textAlign:'center' }}>
              <div style={{ width:'64px', height:'64px', borderRadius:'16px', background:'var(--color-orange-light)', border:'1px solid var(--color-orange-mid)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <File size={28} style={{ color:'var(--color-orange)' }} />
              </div>
              <div>
                <p style={{ fontWeight:600, color:'var(--color-navy)', marginBottom:'4px' }}>{file.name}</p>
                <p style={{ fontSize:'0.875rem', color:'var(--color-text-muted)' }}>Preview not available for {file.ext.toUpperCase()} files.</p>
              </div>
              <button
                onClick={() => dl(file.file, file.name)}
                style={{ display:'flex', alignItems:'center', gap:'8px', padding:'9px 20px', borderRadius:'10px', fontSize:'0.875rem', fontWeight:700, border:'none', cursor:'pointer', background:'var(--color-navy)', color:'#fff', fontFamily:'var(--font-display)' }}
              >
                <Download size={14} /> Download File
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function TextPreview({ url }: { url: string }) {
  const ref = useRef<HTMLPreElement>(null);
  useEffect(() => { fetch(url).then(r => r.text()).then(t => { if (ref.current) ref.current.textContent = t; }); }, [url]);
  return <pre ref={ref} style={{ width:'100%', maxHeight:'70vh', overflow:'auto', padding:'1.5rem', margin:0, fontSize:'0.8rem', lineHeight:1.7, fontFamily:'var(--font-mono)', color:'var(--color-text)', background:'#f8fafc' }} />;
}
