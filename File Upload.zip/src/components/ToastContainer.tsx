import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from 'lucide-react';
import type { Toast } from '../types/upload';

const icons = {
  success: <CheckCircle size={15} style={{ color:'var(--color-success)', flexShrink:0, marginTop:'1px' }} />,
  error:   <AlertCircle size={15} style={{ color:'var(--color-error)',   flexShrink:0, marginTop:'1px' }} />,
  warning: <AlertTriangle size={15} style={{ color:'var(--color-warning)', flexShrink:0, marginTop:'1px' }} />,
  info:    <Info size={15} style={{ color:'var(--color-orange)',  flexShrink:0, marginTop:'1px' }} />,
};

export default function ToastContainer({ toasts, onRemove }: { toasts: Toast[]; onRemove: (id: string) => void }) {
  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.id} className="toast" role="alert">
          {icons[t.type]}
          <span style={{ flex:1, lineHeight:1.45 }}>{t.message}</span>
          <button
            onClick={() => onRemove(t.id)}
            style={{ background:'none', border:'none', cursor:'pointer', opacity:0.4, color:'var(--color-text-muted)', display:'flex', padding:0 }}
            onMouseEnter={e => (e.currentTarget.style.opacity='0.9')}
            onMouseLeave={e => (e.currentTarget.style.opacity='0.4')}
          >
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
