import { useRef, useState } from 'react';
import { UploadCloud } from 'lucide-react';

interface Props { onFiles: (files: File[]) => void; fileCount: number; }

export default function FileDropZone({ onFiles, fileCount }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  function onDrop(e: React.DragEvent) {
    e.preventDefault(); setDragging(false);
    const items = Array.from(e.dataTransfer.files);
    if (items.length) onFiles(items);
  }
  function onDragOver(e: React.DragEvent) { e.preventDefault(); setDragging(true); }
  function onDragLeave() { setDragging(false); }
  function onInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (files.length) onFiles(files);
    e.target.value = '';
  }

  return (
    <div
      className={dragging ? 'drop-zone-active' : ''}
      style={{
        position:'relative', borderRadius:'14px', cursor:'pointer',
        border: `2px dashed ${dragging ? 'var(--color-orange)' : 'var(--color-border-light)'}`,
        background: dragging ? 'var(--color-orange-light)' : 'var(--color-surface)',
        transition:'all 0.18s', boxShadow:'0 1px 4px rgba(13,27,42,0.06)',
      }}
      onDrop={onDrop} onDragOver={onDragOver} onDragLeave={onDragLeave}
      onClick={() => inputRef.current?.click()}
    >
      <input
        ref={inputRef} type="file" multiple className="sr-only"
        accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.ppt,.pptx,.txt,.jpg,.jpeg,.png,.gif,.zip,.rar"
        onChange={onInputChange} tabIndex={-1} aria-label="Choose files"
      />

      <div className="drop-zone-inner" style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'0.75rem', padding:'2.5rem 2rem', minHeight:'160px' }}>
        {/* Icon */}
        <div style={{
          width:'52px', height:'52px', borderRadius:'14px',
          background: dragging ? 'var(--color-orange)' : 'var(--color-navy)',
          display:'flex', alignItems:'center', justifyContent:'center',
          transition:'all 0.18s',
          transform: dragging ? 'scale(1.06)' : 'scale(1)',
          boxShadow: dragging ? '0 4px 16px rgba(249,115,22,0.3)' : '0 4px 12px rgba(13,27,42,0.15)',
        }}>
          <UploadCloud size={24} color="#fff" />
        </div>

        {/* Text */}
        <div style={{ textAlign:'center' }}>
          <p style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'0.9375rem', color:'var(--color-navy)', marginBottom:'3px' }}>
            {dragging ? 'Drop files to add to queue' : 'Drag & Drop Multiple Files Here'}
          </p>
          <p style={{ fontSize:'0.8125rem', color:'var(--color-text-muted)' }}>
            or <span style={{ color:'var(--color-orange)', fontWeight:600 }}>Browse Files</span>
          </p>
        </div>

        {/* Types */}
        <p style={{ fontSize:'0.72rem', color:'var(--color-text-dim)', fontFamily:'var(--font-mono)', letterSpacing:'0.03em', textAlign:'center' }}>
          PDF · DOC · XLS · PPT · TXT · JPG · PNG · ZIP &nbsp;·&nbsp; 10 MB max
        </p>
      </div>

      {/* Queue badge */}
      {fileCount > 0 && (
        <div
          onClick={e => e.stopPropagation()}
          style={{
            position:'absolute', top:'12px', right:'12px',
            padding:'3px 10px', borderRadius:'999px', fontSize:'0.72rem', fontWeight:700,
            background:'var(--color-navy)', color:'#fff',
            fontFamily:'var(--font-mono)',
            boxShadow:'0 2px 8px rgba(13,27,42,0.2)',
          }}
        >
          {fileCount} in queue
        </div>
      )}
    </div>
  );
}
