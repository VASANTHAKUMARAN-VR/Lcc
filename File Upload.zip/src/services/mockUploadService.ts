export function uploadFile(
  file: File,
  onProgress: (p: number) => void,
  signal: AbortSignal
): Promise<void> {
  return new Promise((resolve, reject) => {
    const duration = 2000 + Math.random() * 4000;
    const fail = Math.random() < 0.12;
    const failAt = 30 + Math.random() * 50;
    let progress = 0;
    let startTime = Date.now();

    if (signal.aborted) { reject(new Error('cancelled')); return; }

    const onAbort = () => { reject(new Error('cancelled')); };
    signal.addEventListener('abort', onAbort, { once: true });

    function tick() {
      if (signal.aborted) return;
      const elapsed = Date.now() - startTime;
      progress = Math.min(100, (elapsed / duration) * 100);
      if (fail && progress >= failAt) {
        signal.removeEventListener('abort', onAbort);
        onProgress(Math.round(failAt));
        reject(new Error('Upload failed'));
        return;
      }
      onProgress(Math.round(progress));
      if (progress >= 100) {
        signal.removeEventListener('abort', onAbort);
        resolve();
      } else {
        requestAnimationFrame(tick);
      }
    }

    requestAnimationFrame(tick);
  });
}
