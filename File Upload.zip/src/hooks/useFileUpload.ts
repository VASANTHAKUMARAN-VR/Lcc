import { useState, useCallback, useRef } from 'react';
import type { UploadFile, StoredFile } from '../types/upload';
import { uploadFile } from '../services/mockUploadService';

const CONCURRENCY = 5;

const ALLOWED_EXTENSIONS = new Set([
  'pdf','doc','docx','xls','xlsx','csv','ppt','pptx','txt',
  'jpg','jpeg','png','gif','zip','rar',
]);
const MAX_SIZE = 10 * 1024 * 1024;

function getExt(name: string): string {
  return name.split('.').pop()?.toLowerCase() ?? '';
}

function fileId(file: File): string {
  return `${file.name}__${file.size}__${file.lastModified}`;
}

export function useFileUpload(
  addToast: (type: 'success'|'error'|'warning'|'info', msg: string) => void,
  onFilesStored?: (files: StoredFile[]) => void,
) {
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [uploading, setUploading] = useState(false);

  // Keep a ref mirror so async callbacks see current state without stale closures
  const filesRef = useRef<UploadFile[]>([]);
  const abortRefs = useRef<Map<string, AbortController>>(new Map());
  const queueRef = useRef<string[]>([]);
  const activeRef = useRef<Set<string>>(new Set());

  function applyFiles(updater: (prev: UploadFile[]) => UploadFile[]) {
    setFiles(prev => {
      const next = updater(prev);
      filesRef.current = next;
      return next;
    });
  }

  const updateFile = useCallback((id: string, patch: Partial<UploadFile>) => {
    applyFiles(prev => prev.map(f => f.id === id ? { ...f, ...patch } : f));
  }, []);

  // startNext reads from filesRef.current — never called inside a setFiles updater
  const startNext = useCallback(() => {
    while (activeRef.current.size < CONCURRENCY && queueRef.current.length > 0) {
      const id = queueRef.current.shift()!;
      const fileItem = filesRef.current.find(f => f.id === id);
      if (!fileItem) continue;

      activeRef.current.add(id);
      const ctrl = new AbortController();
      abortRefs.current.set(id, ctrl);

      updateFile(id, { status: 'uploading', progress: 0 });

      uploadFile(fileItem.file, (p) => {
        updateFile(id, { progress: p });
      }, ctrl.signal)
        .then(() => {
          updateFile(id, { status: 'completed', progress: 100 });
          addToast('success', `"${fileItem.name}" uploaded.`);
          if (onFilesStored) {
            onFilesStored([{
              id: fileItem.id,
              file: fileItem.file,
              name: fileItem.name,
              size: fileItem.size,
              ext: fileItem.ext,
              uploadedAt: new Date(),
            }]);
          }
        })
        .catch((err) => {
          if (err.message === 'cancelled') {
            updateFile(id, { status: 'pending', progress: 0 });
          } else {
            updateFile(id, { status: 'failed' });
          }
        })
        .finally(() => {
          activeRef.current.delete(id);
          abortRefs.current.delete(id);

          // Check completion and drain queue — deferred so state has settled
          setTimeout(() => {
            startNext();
            if (activeRef.current.size === 0 && queueRef.current.length === 0) {
              setUploading(false);
              const cur = filesRef.current;
              const completed = cur.filter(f => f.status === 'completed').length;
              const failed = cur.filter(f => f.status === 'failed').length;
              addToast(
                failed > 0 ? 'warning' : 'success',
                `Upload complete. ${completed} succeeded, ${failed} failed.`
              );
            }
          }, 0);
        });
    }
  }, [updateFile, addToast]);

  const addFiles = useCallback((incoming: File[]) => {
    const existingIds = new Set(filesRef.current.map(f => fileId(f.file)));
    let dupes = 0, invalid = 0;
    const valid: UploadFile[] = [];

    for (const file of incoming) {
      const id = fileId(file);
      if (existingIds.has(id)) { dupes++; continue; }
      const ext = getExt(file.name);
      if (!ALLOWED_EXTENSIONS.has(ext)) { invalid++; continue; }
      if (file.size > MAX_SIZE) {
        addToast('error', `"${file.name}" exceeds 10 MB limit.`);
        continue;
      }
      existingIds.add(id);
      valid.push({
        id, file,
        name: file.name,
        size: file.size,
        type: file.type || ext.toUpperCase(),
        ext,
        status: 'pending',
        progress: 0,
        selected: true,
      });
    }

    if (dupes > 0) addToast('warning', `${dupes} duplicate file${dupes > 1 ? 's' : ''} skipped.`);
    if (invalid > 0) addToast('error', `${invalid} unsupported file type${invalid > 1 ? 's' : ''} rejected.`);
    if (valid.length > 0) {
      applyFiles(prev => [...prev, ...valid]);
      addToast('info', `${valid.length} file${valid.length > 1 ? 's' : ''} added to queue.`);
    }
  }, [addToast]);

  const uploadAll = useCallback(() => {
    const toUpload = filesRef.current.filter(
      f => f.selected && (f.status === 'pending' || f.status === 'failed')
    );
    if (toUpload.length === 0) return;
    queueRef.current.push(...toUpload.map(f => f.id));
    setUploading(true);
    addToast('info', `Uploading ${toUpload.length} file${toUpload.length > 1 ? 's' : ''}…`);
    startNext();
  }, [startNext, addToast]);

  const cancelAll = useCallback(() => {
    abortRefs.current.forEach(ctrl => ctrl.abort());
    queueRef.current = [];
    activeRef.current.clear();
    setUploading(false);
    applyFiles(prev => prev.map(f =>
      f.status === 'uploading' || f.status === 'pending'
        ? { ...f, status: 'pending', progress: 0 }
        : f
    ));
  }, []);

  const retryFailed = useCallback(() => {
    const failed = filesRef.current.filter(f => f.status === 'failed');
    if (failed.length === 0) return;
    applyFiles(prev => prev.map(f =>
      f.status === 'failed' ? { ...f, status: 'pending', progress: 0 } : f
    ));
    queueRef.current.push(...failed.map(f => f.id));
    setUploading(true);
    startNext();
  }, [startNext]);

  const removeFile = useCallback((id: string) => {
    abortRefs.current.get(id)?.abort();
    activeRef.current.delete(id);
    queueRef.current = queueRef.current.filter(q => q !== id);
    applyFiles(prev => prev.filter(f => f.id !== id));
  }, []);

  const removeSelected = useCallback(() => {
    const selected = filesRef.current.filter(f => f.selected);
    selected.forEach(f => {
      abortRefs.current.get(f.id)?.abort();
      activeRef.current.delete(f.id);
    });
    queueRef.current = queueRef.current.filter(id => !selected.find(f => f.id === id));
    applyFiles(prev => prev.filter(f => !f.selected));
  }, []);

  const clearAll = useCallback(() => {
    abortRefs.current.forEach(ctrl => ctrl.abort());
    abortRefs.current.clear();
    activeRef.current.clear();
    queueRef.current = [];
    setUploading(false);
    applyFiles(() => []);
  }, []);

  const toggleSelect = useCallback((id: string) => {
    applyFiles(prev => prev.map(f => f.id === id ? { ...f, selected: !f.selected } : f));
  }, []);

  const toggleSelectAll = useCallback((checked: boolean) => {
    applyFiles(prev => prev.map(f => ({ ...f, selected: checked })));
  }, []);

  return {
    files, uploading,
    addFiles, uploadAll, cancelAll, retryFailed,
    removeFile, removeSelected, clearAll,
    toggleSelect, toggleSelectAll,
  };
}
