export type UploadStatus = 'pending' | 'uploading' | 'completed' | 'failed' | 'cancelled';

export interface UploadFile {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  ext: string;
  status: UploadStatus;
  progress: number;
  error?: string;
  selected: boolean;
}

export interface StoredFile {
  id: string;
  file: File;          // keep reference for download/preview
  name: string;
  size: number;
  ext: string;
  uploadedAt: Date;
}

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
}
