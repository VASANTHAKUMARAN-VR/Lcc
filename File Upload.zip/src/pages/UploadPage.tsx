import { useFileUpload } from '../hooks/useFileUpload';
import FileDropZone from '../components/FileDropZone';
import FileTable from '../components/FileTable';
import OverallProgress from '../components/OverallProgress';
import UploadControls from '../components/UploadControls';
import FileViewer from '../components/FileViewer';
import { useState } from 'react';
import type { StoredFile } from '../types/upload';

interface Props {
  addToast: (type: 'success'|'error'|'warning'|'info', msg: string) => void;
  onFilesStored: (files: StoredFile[]) => void;
}

export default function UploadPage({ addToast, onFilesStored }: Props) {
  const [viewingId, setViewingId] = useState<string | null>(null);

  const {
    files, uploading,
    addFiles, uploadAll, cancelAll, retryFailed,
    removeFile, removeSelected, clearAll,
    toggleSelect, toggleSelectAll,
  } = useFileUpload(addToast, onFilesStored);

  const viewingFile = viewingId ? files.find(f => f.id === viewingId) ?? null : null;

  function handleClearAll() {
    if (files.length === 0) return;
    if (window.confirm(`Remove all ${files.length} files from the queue?`)) clearAll();
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:'1rem' }}>

      {/* Drop zone */}
      <FileDropZone onFiles={addFiles} fileCount={files.length} />

      {/* Progress summary */}
      {files.length > 0 && (
        <OverallProgress files={files} uploading={uploading} />
      )}

      {/* Controls */}
      {files.length > 0 && (
        <UploadControls
          files={files} uploading={uploading}
          onUploadAll={uploadAll} onCancelAll={cancelAll}
          onRetryFailed={retryFailed} onRemoveSelected={removeSelected}
          onClearAll={handleClearAll}
        />
      )}

      {/* File list */}
      {files.length > 0 && (
        <FileTable
          files={files}
          onToggle={id => toggleSelect(id)}
          onToggleAll={toggleSelectAll}
          onRemove={removeFile}
          onRetry={retryFailed}
          onView={id => setViewingId(id)}
        />
      )}

      {files.length === 0 && (
        <div style={{ textAlign:'center', padding:'3rem 0', color:'var(--color-text-dim)' }}>
          <p style={{ fontSize:'0.875rem' }}>No files in queue. Drag & drop or choose files above.</p>
        </div>
      )}

      {/* Viewer modal */}
      {viewingFile && <FileViewer file={viewingFile} onClose={() => setViewingId(null)} />}
    </div>
  );
}
