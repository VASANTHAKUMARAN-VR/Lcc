import { useState } from 'react';
import { LogOut, FileText, UploadCloud, FolderOpen } from 'lucide-react';
import type { StoredFile } from '../types/upload';
import UploadPage from './UploadPage';
import ViewFilesPage from './ViewFilesPage';

interface Props {
  username: string;
  onLogout: () => void;
  addToast: (type: 'success'|'error'|'warning'|'info', msg: string) => void;
}

type Tab = 'upload' | 'files';

export default function DashboardPage({ username, onLogout, addToast }: Props) {
  const [tab,         setTab]         = useState<Tab>('upload');
  const [storedFiles, setStoredFiles] = useState<StoredFile[]>([]);

  function handleFilesStored(incoming: StoredFile[]) {
    setStoredFiles(prev => {
      const existingIds = new Set(prev.map(f => f.id));
      const fresh = incoming.filter(f => !existingIds.has(f.id));
      return fresh.length > 0 ? [...prev, ...fresh] : prev;
    });
  }

  function handleDelete(id: string) {
    setStoredFiles(prev => prev.filter(f => f.id !== id));
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id:'upload', label:'Upload Files', icon:<UploadCloud size={16}/> },
    { id:'files',  label:'View Files',   icon:<FolderOpen  size={16}/>, badge: storedFiles.length || undefined },
  ];

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column', background:'var(--color-bg)', fontFamily:'var(--font-sans)' }}>

      {/* ── Header ── */}
      <header style={{ position:'sticky', top:0, zIndex:40, background:'var(--color-navy)', borderBottom:'1px solid rgba(255,255,255,0.07)', boxShadow:'0 2px 16px rgba(13,40,71,0.25)' }}>
        <div className="dash-header-inner">

          {/* Logo */}
          <div style={{ display:'flex', alignItems:'center', gap:'8px', flexShrink:0 }}>
            <div style={{ width:'32px', height:'32px', borderRadius:'8px', background:'var(--color-orange)', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 2px 8px rgba(249,115,22,0.35)', flexShrink:0 }}>
              <FileText size={16} color="#fff" />
            </div>
            <span style={{ fontFamily:'var(--font-display)', fontWeight:800, fontSize:'1rem', color:'#fff', letterSpacing:'-0.01em', whiteSpace:'nowrap' }}>DocPortal</span>
          </div>

          {/* Nav tabs */}
          <nav style={{ display:'flex', alignItems:'center', gap:'4px', flex:1, marginLeft:'8px' }}>
            {tabs.map(t => {
              const active = tab === t.id;
              return (
                <button key={t.id} onClick={() => setTab(t.id)}
                  style={{ display:'flex', alignItems:'center', gap:'6px', padding:'6px 12px', borderRadius:'8px', border:'none', cursor:'pointer', fontSize:'0.84rem', fontWeight:600, transition:'all 0.15s', background:active ? 'rgba(255,255,255,0.12)' : 'transparent', color:active ? '#fff' : 'rgba(255,255,255,0.5)', whiteSpace:'nowrap' }}
                  onMouseEnter={e => { if(!active){ e.currentTarget.style.background='rgba(255,255,255,0.07)'; e.currentTarget.style.color='rgba(255,255,255,0.8)'; }}}
                  onMouseLeave={e => { if(!active){ e.currentTarget.style.background='transparent'; e.currentTarget.style.color='rgba(255,255,255,0.5)'; }}}
                >
                  {t.icon}
                  <span className="dash-nav-label">{t.label}</span>
                  {t.badge ? (
                    <span style={{ minWidth:'18px', height:'17px', borderRadius:'9px', background:'var(--color-orange)', color:'#fff', fontSize:'0.65rem', fontWeight:800, display:'inline-flex', alignItems:'center', justifyContent:'center', padding:'0 5px' }}>
                      {t.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          {/* User + sign out */}
          <div style={{ display:'flex', alignItems:'center', gap:'8px', marginLeft:'auto', flexShrink:0 }}>
            <div style={{ display:'flex', alignItems:'center', gap:'7px' }}>
              <div style={{ width:'30px', height:'30px', borderRadius:'50%', background:'rgba(255,255,255,0.1)', border:'1.5px solid rgba(255,255,255,0.15)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'0.75rem', fontWeight:700, color:'#fff', fontFamily:'var(--font-mono)', flexShrink:0 }}>
                {username[0]?.toUpperCase()}
              </div>
              <span className="dash-username" style={{ fontSize:'0.84rem', fontWeight:500, color:'rgba(255,255,255,0.65)', whiteSpace:'nowrap' }}>{username}</span>
            </div>
            <button
              onClick={() => { addToast('info','You have been signed out.'); onLogout(); }}
              style={{ display:'flex', alignItems:'center', gap:'5px', padding:'6px 10px', borderRadius:'8px', border:'1px solid rgba(255,255,255,0.1)', cursor:'pointer', fontSize:'0.78rem', fontWeight:600, background:'rgba(255,255,255,0.06)', color:'rgba(255,255,255,0.5)', transition:'all 0.15s', whiteSpace:'nowrap' }}
              onMouseEnter={e => { e.currentTarget.style.background='rgba(239,68,68,0.18)'; e.currentTarget.style.color='#f87171'; (e.currentTarget.style as any).borderColor='rgba(239,68,68,0.35)'; }}
              onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,0.06)'; e.currentTarget.style.color='rgba(255,255,255,0.5)'; (e.currentTarget.style as any).borderColor='rgba(255,255,255,0.1)'; }}
            >
              <LogOut size={13} />
              <span className="dash-nav-label">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* ── Main ── */}
      <main className="dash-main">

        {/* Page heading */}
        <div className="animate-slide-up" style={{ marginBottom:'1.5rem' }}>
          <div style={{ display:'flex', alignItems:'center', gap:'9px', marginBottom:'0.35rem' }}>
            <div style={{ width:'18px', height:'2px', background:'var(--color-orange)', borderRadius:'1px', flexShrink:0 }} />
            <span style={{ fontSize:'0.67rem', fontWeight:700, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--color-orange)' }}>
              {tab === 'upload' ? 'Document Upload' : 'Uploaded Documents'}
            </span>
          </div>
          <h1 className="page-heading-h1" style={{ fontFamily:'var(--font-display)', fontWeight:800, fontSize:'1.625rem', color:'var(--color-navy)', lineHeight:1.2, marginBottom:'0.25rem' }}>
            {tab === 'upload' ? 'Upload Documents' : 'View Files'}
          </h1>
          <p style={{ fontSize:'0.875rem', color:'var(--color-text-muted)', lineHeight:1.6 }}>
            {tab === 'upload'
              ? 'Select multiple files, queue them, and upload concurrently — then preview or download anytime.'
              : `${storedFiles.length} file${storedFiles.length !== 1 ? 's' : ''} stored this session. Preview or download instantly.`}
          </p>
        </div>

        {tab === 'upload'
          ? <UploadPage addToast={addToast} onFilesStored={handleFilesStored} />
          : <ViewFilesPage storedFiles={storedFiles} onDelete={handleDelete} />}
      </main>
    </div>
  );
}
