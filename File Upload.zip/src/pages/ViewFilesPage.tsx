import { useState } from 'react';
import { Eye, Download, Search, FileText, Trash2, X } from 'lucide-react';
import type { StoredFile, UploadFile } from '../types/upload';
import FileIcon from '../components/FileIcon';
import FileViewer from '../components/FileViewer';

interface Props {
  storedFiles: StoredFile[];
  onDelete: (id: string) => void;
}

function fmt(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(0)} KB`;
  return `${(b / 1024 / 1024).toFixed(1)} MB`;
}

function fmtDate(d: Date) {
  return d.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }) +
    ' ' + d.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' });
}

function dl(file: File, name: string) {
  const url = URL.createObjectURL(file);
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

function toUploadFile(sf: StoredFile): UploadFile {
  return { id:sf.id, file:sf.file, name:sf.name, size:sf.size, type:sf.file.type, ext:sf.ext, status:'completed', progress:100, selected:false };
}

const IMAGE_EXTS = new Set(['jpg','jpeg','png','gif','webp']);

const FILE_TYPES = ['PDF','DOC','XLS','PPT','TXT','JPG','PNG','ZIP'];

const EXT_MAP: Record<string, string[]> = {
  PDF: ['pdf'],
  DOC: ['doc','docx'],
  XLS: ['xls','xlsx','csv'],
  PPT: ['ppt','pptx'],
  TXT: ['txt'],
  JPG: ['jpg','jpeg'],
  PNG: ['png','gif','webp'],
  ZIP: ['zip','rar'],
};

export default function ViewFilesPage({ storedFiles, onDelete }: Props) {
  const [query,      setQuery]      = useState('');
  const [activeType, setActiveType] = useState<string | null>(null);
  const [viewingId,  setViewingId]  = useState<string | null>(null);
  const [view,       setView]       = useState<'list'|'grid'>('list');

  const viewingFile = viewingId ? storedFiles.find(f => f.id === viewingId) : null;

  const filtered = storedFiles.filter(f => {
    const matchSearch = f.name.toLowerCase().includes(query.toLowerCase());
    const matchType   = !activeType || (EXT_MAP[activeType] ?? []).includes(f.ext);
    return matchSearch && matchType;
  });

  const typeCounts: Record<string, number> = {};
  FILE_TYPES.forEach(t => {
    typeCounts[t] = storedFiles.filter(f => (EXT_MAP[t] ?? []).includes(f.ext)).length;
  });

  if (storedFiles.length === 0) {
    return (
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'5rem 0', textAlign:'center', gap:'1rem' }}>
        <div style={{ width:'64px', height:'64px', borderRadius:'16px', background:'var(--color-surface-2)', border:'1px solid var(--color-border)', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <FileText size={28} style={{ color:'var(--color-text-dim)' }} />
        </div>
        <div>
          <p style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:'1rem', color:'var(--color-navy)', marginBottom:'4px' }}>No files uploaded yet</p>
          <p style={{ fontSize:'0.875rem', color:'var(--color-text-muted)' }}>Go to <strong>Upload Files</strong> to add documents.</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:'1rem' }}>

      {/* ── Type filter pills ── */}
      <div className="type-filters">
        <button
          onClick={() => setActiveType(null)}
          style={{ padding:'5px 12px', borderRadius:'999px', fontSize:'0.78rem', fontWeight:600, border:'1.5px solid', cursor:'pointer', transition:'all 0.15s', flexShrink:0,
            background: !activeType ? 'var(--color-navy)' : 'var(--color-surface)',
            color: !activeType ? '#fff' : 'var(--color-text-muted)',
            borderColor: !activeType ? 'var(--color-navy)' : 'var(--color-border)',
          }}
        >
          All <span style={{ marginLeft:'4px', opacity:0.65 }}>{storedFiles.length}</span>
        </button>

        {FILE_TYPES.filter(t => typeCounts[t] > 0).map(t => {
          const active = activeType === t;
          return (
            <button key={t} onClick={() => setActiveType(active ? null : t)}
              style={{ padding:'5px 12px', borderRadius:'999px', fontSize:'0.78rem', fontWeight:600, border:'1.5px solid', cursor:'pointer', transition:'all 0.15s', flexShrink:0,
                background: active ? 'var(--color-orange)' : 'var(--color-surface)',
                color: active ? '#fff' : 'var(--color-text-muted)',
                borderColor: active ? 'var(--color-orange)' : 'var(--color-border)',
              }}
              onMouseEnter={e => { if(!active){ e.currentTarget.style.borderColor='var(--color-orange)'; e.currentTarget.style.color='var(--color-orange)'; }}}
              onMouseLeave={e => { if(!active){ e.currentTarget.style.borderColor='var(--color-border)'; e.currentTarget.style.color='var(--color-text-muted)'; }}}
            >
              {t} <span style={{ marginLeft:'4px', opacity:0.65 }}>{typeCounts[t]}</span>
            </button>
          );
        })}
      </div>

      {/* ── Toolbar ── */}
      <div style={{ display:'flex', alignItems:'center', gap:'10px', flexWrap:'wrap' }}>
        <div style={{ position:'relative', flex:1, minWidth:'160px', maxWidth:'340px' }}>
          <Search size={14} style={{ position:'absolute', left:'12px', top:'50%', transform:'translateY(-50%)', color:'var(--color-text-dim)', pointerEvents:'none' }} />
          <input
            type="text" value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Search files…"
            style={{ width:'100%', paddingLeft:'36px', paddingRight: query ? '32px' : '12px', paddingTop:'8px', paddingBottom:'8px', borderRadius:'9px', fontSize:'0.8125rem', outline:'none', background:'var(--color-surface)', border:'1.5px solid var(--color-border)', color:'var(--color-text)', transition:'border-color 0.15s' }}
            onFocus={e => (e.target.style.borderColor='var(--color-navy)')}
            onBlur={e  => (e.target.style.borderColor='var(--color-border)')}
          />
          {query && (
            <button onClick={() => setQuery('')} style={{ position:'absolute', right:'10px', top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'var(--color-text-dim)', display:'flex', padding:0 }}>
              <X size={13} />
            </button>
          )}
        </div>

        <span style={{ fontSize:'0.8rem', color:'var(--color-text-dim)', marginLeft:'auto', whiteSpace:'nowrap' }}>
          {filtered.length} of {storedFiles.length} file{storedFiles.length !== 1 ? 's' : ''}
        </span>

        <div style={{ display:'flex', borderRadius:'8px', overflow:'hidden', border:'1px solid var(--color-border)', flexShrink:0 }}>
          {(['list','grid'] as const).map(v => (
            <button key={v} onClick={() => setView(v)}
              style={{ padding:'6px 12px', fontSize:'0.78rem', fontWeight:600, border:'none', cursor:'pointer', background: view === v ? 'var(--color-navy)' : 'var(--color-surface)', color: view === v ? '#fff' : 'var(--color-text-muted)', transition:'all 0.12s', textTransform:'capitalize' }}
            >
              {v}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 && (
        <div style={{ padding:'3rem', textAlign:'center', color:'var(--color-text-dim)', fontSize:'0.875rem', background:'var(--color-surface)', borderRadius:'14px', border:'1px solid var(--color-border)' }}>
          No files match your filter.
        </div>
      )}

      {/* ── Grid view ── */}
      {view === 'grid' && filtered.length > 0 && (
        <div className="vf-grid" style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(170px, 1fr))', gap:'12px' }}>
          {filtered.map(sf => (
            <div key={sf.id}
              style={{ borderRadius:'12px', background:'var(--color-surface)', border:'1px solid var(--color-border)', overflow:'hidden', display:'flex', flexDirection:'column', boxShadow:'0 1px 4px rgba(13,40,71,0.06)', transition:'box-shadow 0.15s' }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow='0 4px 16px rgba(13,40,71,0.12)')}
              onMouseLeave={e => (e.currentTarget.style.boxShadow='0 1px 4px rgba(13,40,71,0.06)')}
            >
              <div style={{ height:'100px', background:'var(--color-surface-2)', display:'flex', alignItems:'center', justifyContent:'center', borderBottom:'1px solid var(--color-border)' }}>
                {IMAGE_EXTS.has(sf.ext)
                  ? <img src={URL.createObjectURL(sf.file)} alt={sf.name} style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                  : <FileIcon ext={sf.ext} size={38} />}
              </div>
              <div style={{ padding:'9px 12px', flex:1 }}>
                <p style={{ fontSize:'0.78rem', fontWeight:600, color:'var(--color-navy)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', marginBottom:'2px' }} title={sf.name}>{sf.name}</p>
                <p style={{ fontSize:'0.7rem', color:'var(--color-text-dim)', fontFamily:'var(--font-mono)' }}>{fmt(sf.size)}</p>
              </div>
              <div style={{ display:'flex', borderTop:'1px solid var(--color-border)' }}>
                {[
                  { icon:<Eye size={12}/>,      title:'Preview',  onClick:() => setViewingId(sf.id), hc:'var(--color-navy)' },
                  { icon:<Download size={12}/>, title:'Download', onClick:() => dl(sf.file, sf.name), hc:'var(--color-success)' },
                  { icon:<Trash2 size={12}/>,   title:'Delete',   onClick:() => onDelete(sf.id), hc:'var(--color-error)' },
                ].map((a,i) => (
                  <button key={i} onClick={a.onClick} title={a.title}
                    style={{ flex:1, padding:'7px', border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--color-text-dim)', transition:'all 0.12s', borderRight: i < 2 ? '1px solid var(--color-border)' : 'none' }}
                    onMouseEnter={e => { e.currentTarget.style.background=`${a.hc}18`; e.currentTarget.style.color=a.hc; }}
                    onMouseLeave={e => { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--color-text-dim)'; }}
                  >
                    {a.icon}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── List view ── */}
      {view === 'list' && filtered.length > 0 && (
        <div style={{ borderRadius:'14px', overflow:'hidden', background:'var(--color-surface)', border:'1px solid var(--color-border)', boxShadow:'0 1px 4px rgba(13,40,71,0.06)' }}>

          {/* Desktop/tablet header */}
          <div className="vf-list-head">
            {[' ','File Name','Size','Uploaded','Actions'].map((h,i) => (
              <span key={i} className={i === 3 ? 'vf-col-date' : ''} style={{ fontSize:'0.7rem', fontWeight:700, color:'rgba(255,255,255,0.45)', textTransform:'uppercase', letterSpacing:'0.08em', textAlign: i === 4 ? 'right' : 'left' }}>{h}</span>
            ))}
          </div>

          {filtered.map((sf, idx) => (
            <div key={sf.id}>
              {/* Desktop/tablet row */}
              <div
                className="vf-list-row"
                onMouseEnter={e => (e.currentTarget.style.background='#f8fafc')}
                onMouseLeave={e => (e.currentTarget.style.background='transparent')}
                style={{ borderBottom: idx < filtered.length-1 ? '1px solid var(--color-border)' : 'none' }}
              >
                <FileIcon ext={sf.ext} size={26} />
                <div style={{ minWidth:0 }}>
                  <p style={{ fontSize:'0.84rem', fontWeight:500, color:'var(--color-text)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }} title={sf.name}>{sf.name}</p>
                  <span style={{ fontSize:'0.68rem', fontFamily:'var(--font-mono)', color:'var(--color-text-dim)', textTransform:'uppercase' }}>{sf.ext}</span>
                </div>
                <span style={{ fontSize:'0.78rem', fontFamily:'var(--font-mono)', color:'var(--color-text-dim)' }}>{fmt(sf.size)}</span>
                <span className="vf-col-date" style={{ fontSize:'0.75rem', color:'var(--color-text-dim)' }}>{fmtDate(sf.uploadedAt)}</span>
                <div style={{ display:'flex', gap:'3px', justifyContent:'flex-end' }}>
                  {[
                    { icon:<Eye size={13}/>,      title:'Preview',  onClick:() => setViewingId(sf.id), hb:'var(--color-blue-light)',  hc:'var(--color-blue)' },
                    { icon:<Download size={13}/>, title:'Download', onClick:() => dl(sf.file, sf.name), hb:'var(--color-success-bg)', hc:'var(--color-success)' },
                    { icon:<Trash2 size={13}/>,   title:'Delete',   onClick:() => onDelete(sf.id),     hb:'var(--color-error-bg)',   hc:'var(--color-error)' },
                  ].map((a,i) => (
                    <button key={i} onClick={a.onClick} title={a.title}
                      style={{ width:'28px', height:'28px', borderRadius:'7px', border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--color-text-dim)', transition:'all 0.12s' }}
                      onMouseEnter={e => { e.currentTarget.style.background=a.hb; e.currentTarget.style.color=a.hc; }}
                      onMouseLeave={e => { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--color-text-dim)'; }}
                    >
                      {a.icon}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mobile card */}
              <div className="vf-card" style={{ display:'none', padding:'12px 14px', borderBottom: idx < filtered.length-1 ? '1px solid var(--color-border)' : 'none', alignItems:'center', gap:'10px' }}>
                <FileIcon ext={sf.ext} size={30} />
                <div style={{ flex:1, minWidth:0 }}>
                  <p style={{ fontSize:'0.84rem', fontWeight:600, color:'var(--color-text)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }} title={sf.name}>{sf.name}</p>
                  <p style={{ fontSize:'0.7rem', fontFamily:'var(--font-mono)', color:'var(--color-text-dim)' }}>
                    {fmt(sf.size)} · {sf.uploadedAt.toLocaleDateString('en-GB', { day:'2-digit', month:'short' })}
                  </p>
                </div>
                <div style={{ display:'flex', gap:'3px', flexShrink:0 }}>
                  {[
                    { icon:<Eye size={13}/>,      title:'Preview',  onClick:() => setViewingId(sf.id), hb:'var(--color-blue-light)',  hc:'var(--color-blue)' },
                    { icon:<Download size={13}/>, title:'Download', onClick:() => dl(sf.file, sf.name), hb:'var(--color-success-bg)', hc:'var(--color-success)' },
                    { icon:<Trash2 size={13}/>,   title:'Delete',   onClick:() => onDelete(sf.id),     hb:'var(--color-error-bg)',   hc:'var(--color-error)' },
                  ].map((a,i) => (
                    <button key={i} onClick={a.onClick} title={a.title}
                      style={{ width:'30px', height:'30px', borderRadius:'7px', border:'none', background:'transparent', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--color-text-dim)', transition:'all 0.12s' }}
                      onMouseEnter={e => { e.currentTarget.style.background=a.hb; e.currentTarget.style.color=a.hc; }}
                      onMouseLeave={e => { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--color-text-dim)'; }}
                    >
                      {a.icon}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Viewer modal */}
      {viewingFile && <FileViewer file={toUploadFile(viewingFile)} onClose={() => setViewingId(null)} />}
    </div>
  );
}
