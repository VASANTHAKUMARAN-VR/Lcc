import { useState } from 'react';
import { Eye, EyeOff, Lock, User, ArrowRight, Upload, Eye as ViewIcon, Download, Shield } from 'lucide-react';

interface Props {
  onLogin: (username: string) => void;
  addToast: (type: 'success'|'error'|'warning'|'info', msg: string) => void;
}

const features = [
  { icon: <Upload size={15} />,   label: 'Multi-file upload with drag & drop' },
  { icon: <ViewIcon size={15} />, label: 'Preview images & PDFs in-browser' },
  { icon: <Download size={15} />, label: 'Download any file with one click' },
  { icon: <Shield size={15} />,   label: 'Track upload status & progress live' },
];

export default function LoginPage({ onLogin, addToast }: Props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw,   setShowPw]   = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!username.trim() || !password) { setError('Please enter your credentials.'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 900));
    if (username.trim() === 'admin' && password === 'admin123') {
      addToast('success', 'Welcome back, admin.');
      onLogin(username.trim());
    } else {
      setError('Invalid username or password.');
      addToast('error', 'Authentication failed.');
    }
    setLoading(false);
  }

  const DocIcon = () => (
    <svg width="18" height="18" viewBox="0 0 22 22" fill="none">
      <path d="M4 4h8l6 6v8H4V4z" stroke="#fff" strokeWidth="1.5" strokeLinejoin="round"/>
      <path d="M12 4v6h6" stroke="#fff" strokeWidth="1.5" strokeLinejoin="round"/>
      <path d="M7 13h8M7 16h5" stroke="#fff" strokeWidth="1.2" strokeLinecap="round"/>
    </svg>
  );

  return (
    <div className="login-wrapper">

      {/* ── LEFT panel ── */}
      <div className="login-left login-panel-left dot-grid" style={{ background:'var(--color-navy)', display:'flex', flexDirection:'column', justifyContent:'center', padding:'3rem 5% 3rem 6%', position:'relative', overflow:'hidden' }}>

        {/* Rings */}
        <div style={{ position:'absolute', top:'-80px', right:'-80px', width:'360px', height:'360px', borderRadius:'50%', border:'1px solid rgba(255,255,255,0.06)', pointerEvents:'none' }} />
        <div style={{ position:'absolute', top:'-20px', right:'-20px', width:'180px', height:'180px', borderRadius:'50%', border:'1px solid rgba(255,255,255,0.04)', pointerEvents:'none' }} />
        <div style={{ position:'absolute', bottom:'-80px', left:'-60px', width:'300px', height:'300px', borderRadius:'50%', border:'1px solid rgba(255,255,255,0.04)', pointerEvents:'none' }} />

        {/* Logo */}
        <div className="login-item" style={{ display:'flex', alignItems:'center', gap:'10px', marginBottom:'2.5rem', animationDelay:'0.1s' }}>
          <div style={{ width:'38px', height:'38px', borderRadius:'10px', background:'var(--color-orange)', display:'flex', alignItems:'center', justifyContent:'center', boxShadow:'0 4px 14px rgba(249,115,22,0.4)', flexShrink:0 }}>
            <DocIcon />
          </div>
          <span style={{ fontFamily:'var(--font-display)', fontWeight:800, fontSize:'1.15rem', color:'#fff', letterSpacing:'-0.01em' }}>DocPortal</span>
        </div>

        {/* Eyebrow */}
        <div className="login-item" style={{ display:'flex', alignItems:'center', gap:'10px', marginBottom:'1.1rem', animationDelay:'0.2s' }}>
          <div style={{ width:'24px', height:'2px', background:'var(--color-orange)', borderRadius:'1px', flexShrink:0 }} />
          <span style={{ fontSize:'0.67rem', fontWeight:700, letterSpacing:'0.14em', textTransform:'uppercase', color:'rgba(255,255,255,0.4)' }}>Document Management</span>
        </div>

        {/* Headline */}
        <h1 className="login-item" style={{ animationDelay:'0.28s', fontFamily:'var(--font-display)', fontWeight:800, fontSize:'clamp(1.6rem, 2.4vw, 2.4rem)', lineHeight:1.12, color:'#fff', marginBottom:'0.9rem' }}>
          Upload, preview &<br />
          manage all your{' '}
          <span style={{ color:'var(--color-orange)' }}>documents.</span>
        </h1>

        {/* Sub */}
        <p className="login-item" style={{ animationDelay:'0.36s', fontSize:'0.85rem', lineHeight:1.75, color:'rgba(255,255,255,0.5)', marginBottom:'1.75rem', maxWidth:'380px' }}>
          A clean, fast portal for teams to upload multiple files, preview content instantly, and download what they need — no friction.
        </p>

        {/* Features */}
        <div className="login-item" style={{ display:'flex', flexDirection:'column', gap:'10px', animationDelay:'0.44s' }}>
          {features.map(f => (
            <div key={f.label} style={{ display:'flex', alignItems:'center', gap:'11px' }}>
              <div style={{ width:'30px', height:'30px', borderRadius:'8px', flexShrink:0, background:'rgba(249,115,22,0.14)', border:'1px solid rgba(249,115,22,0.22)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--color-orange)' }}>
                {f.icon}
              </div>
              <span style={{ fontSize:'0.82rem', color:'rgba(255,255,255,0.65)', fontWeight:500 }}>{f.label}</span>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="login-item" style={{ display:'flex', alignItems:'center', gap:'12px', marginTop:'2rem', paddingTop:'1.5rem', borderTop:'1px solid rgba(255,255,255,0.08)', animationDelay:'0.52s' }}>
          <span style={{ fontSize:'0.58rem', fontWeight:800, letterSpacing:'0.1em', textTransform:'uppercase', padding:'3px 8px', borderRadius:'4px', background:'var(--color-orange)', color:'#fff' }}>Secure</span>
          <span style={{ fontSize:'0.76rem', fontWeight:600, color:'rgba(255,255,255,0.3)', fontStyle:'italic' }}>Precision. Performance. Partnership.</span>
        </div>
      </div>

      {/* ── RIGHT panel ── */}
      <div className="login-right login-panel-right" style={{ background:'#fff', padding:'2rem 5%' }}>
        <div style={{ width:'100%', maxWidth:'400px' }}>

          {/* Mobile-only logo */}
          <div className="login-mobile-logo" style={{ display:'none', alignItems:'center', gap:'8px', marginBottom:'2rem' }}>
            <div style={{ width:'34px', height:'34px', borderRadius:'9px', background:'var(--color-navy)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <DocIcon />
            </div>
            <span style={{ fontFamily:'var(--font-display)', fontWeight:800, color:'var(--color-navy)', fontSize:'1.05rem' }}>DocPortal</span>
          </div>

          {/* Heading */}
          <div className="login-item" style={{ marginBottom:'1.6rem', animationDelay:'0.22s' }}>
            <p style={{ fontSize:'0.67rem', fontWeight:700, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--color-orange)', marginBottom:'0.4rem' }}>Welcome Back</p>
            <h2 style={{ fontFamily:'var(--font-display)', fontWeight:800, fontSize:'1.65rem', color:'var(--color-navy)', lineHeight:1.15, marginBottom:'0.35rem' }}>
              Sign in to your account
            </h2>
            <p style={{ fontSize:'0.875rem', color:'var(--color-text-muted)', lineHeight:1.5 }}>Enter your credentials to continue</p>
          </div>

          {/* Form */}
          <form className="login-item" onSubmit={handleSubmit} style={{ display:'flex', flexDirection:'column', gap:'1rem', animationDelay:'0.32s' }}>

            <div>
              <label style={{ display:'block', fontSize:'0.8125rem', fontWeight:600, color:'var(--color-navy)', marginBottom:'6px' }}>Username</label>
              <div style={{ position:'relative' }}>
                <User size={14} style={{ position:'absolute', left:'13px', top:'50%', transform:'translateY(-50%)', color:'var(--color-text-dim)', pointerEvents:'none' }} />
                <input
                  type="text" value={username} onChange={e => setUsername(e.target.value)}
                  placeholder="Enter username" autoComplete="username"
                  style={{ width:'100%', paddingLeft:'38px', paddingRight:'14px', paddingTop:'11px', paddingBottom:'11px', borderRadius:'10px', fontSize:'0.875rem', outline:'none', background:'var(--color-surface-2)', border:'1.5px solid var(--color-border)', color:'var(--color-text)', transition:'border-color 0.15s, background 0.15s' }}
                  onFocus={e => { e.target.style.borderColor='var(--color-navy)'; e.target.style.background='#fff'; }}
                  onBlur={e  => { e.target.style.borderColor='var(--color-border)'; e.target.style.background='var(--color-surface-2)'; }}
                />
              </div>
            </div>

            <div>
              <label style={{ display:'block', fontSize:'0.8125rem', fontWeight:600, color:'var(--color-navy)', marginBottom:'6px' }}>Password</label>
              <div style={{ position:'relative' }}>
                <Lock size={14} style={{ position:'absolute', left:'13px', top:'50%', transform:'translateY(-50%)', color:'var(--color-text-dim)', pointerEvents:'none' }} />
                <input
                  type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="Enter password" autoComplete="current-password"
                  style={{ width:'100%', paddingLeft:'38px', paddingRight:'42px', paddingTop:'11px', paddingBottom:'11px', borderRadius:'10px', fontSize:'0.875rem', outline:'none', background:'var(--color-surface-2)', border:'1.5px solid var(--color-border)', color:'var(--color-text)', transition:'border-color 0.15s, background 0.15s' }}
                  onFocus={e => { e.target.style.borderColor='var(--color-navy)'; e.target.style.background='#fff'; }}
                  onBlur={e  => { e.target.style.borderColor='var(--color-border)'; e.target.style.background='var(--color-surface-2)'; }}
                />
                <button type="button" onClick={() => setShowPw(v => !v)} style={{ position:'absolute', right:'13px', top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'var(--color-text-dim)', opacity:0.6, padding:0, display:'flex' }}>
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="animate-fade-in" style={{ fontSize:'0.8rem', padding:'10px 14px', borderRadius:'8px', color:'var(--color-error)', background:'var(--color-error-bg)', border:'1px solid #fecaca', margin:0 }}>{error}</p>
            )}

            <button
              type="submit" disabled={loading}
              style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'center', gap:'8px', padding:'12px 20px', borderRadius:'10px', marginTop:'4px', fontSize:'0.9rem', fontWeight:700, border:'none', cursor:loading ? 'not-allowed' : 'pointer', background:'var(--color-navy)', color:'#fff', boxShadow:'0 4px 16px rgba(13,40,71,0.25)', opacity:loading ? 0.7 : 1, transition:'background 0.15s', fontFamily:'var(--font-display)', letterSpacing:'0.01em' }}
              onMouseEnter={e => { if(!loading) e.currentTarget.style.background='var(--color-navy-mid)'; }}
              onMouseLeave={e => { e.currentTarget.style.background='var(--color-navy)'; }}
            >
              {loading
                ? <><svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeDasharray="40" strokeDashoffset="10"/></svg> Signing in…</>
                : <>Sign In <ArrowRight size={15} /></>}
            </button>
          </form>

          <div className="login-item" style={{ marginTop:'1.25rem', padding:'12px 16px', borderRadius:'10px', textAlign:'center', fontSize:'0.8125rem', background:'var(--color-orange-light)', border:'1px solid var(--color-orange-mid)', color:'var(--color-orange-hover)', animationDelay:'0.42s' }}>
            Demo —{' '}
            <span style={{ fontFamily:'var(--font-mono)', fontWeight:700 }}>admin</span>
            {' / '}
            <span style={{ fontFamily:'var(--font-mono)', fontWeight:700 }}>admin123</span>
          </div>
        </div>
      </div>
    </div>
  );
}
